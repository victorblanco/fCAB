<?php 
	
	$tmp  	 = "<h3>Se ha produccido un error</h3>";
	$tmp	.= "<code>El departamento t�cnico ya ha sido informado. <br /> <a href='../app/Default' >Volver</a></code>";
	$tmp2 	.= $e->getMessage();
	$tmp2 	.="<pre>".$e->getTraceAsString()."</pre>";
	$tmp2	 = "<H3>".$_SERVER['PHP_SELF']."(".App::getController().".".App::getAction().")</H3>" . $tmp2;
	$tmp2	.= "<h4>REQUEST</h4>";  
	$tmp2	.= var_export($_REQUEST, true)."\n";
	$tmp2	.= "<h4>SESSION</h4>";
	$tmp2	.= var_export($_SESSION, true)."\n";
	$tmp2	.= "<h4>SERVER</h4>";
	$tmp2	.= var_export($_SERVER, true)."\n";

	
	
	if (ENTORNO == DESARROLLO){
		
		$tmp = $tmp . "<pre>" . $tmp2 . "</pre>";
	}else{
		$cabeceras = "Content-type: text/html\r\n";
		
		mail(MAIL, "ERROR " . APPNAME, $tmp. $tmp2, $cabeceras);
		//echo $tmp;
	}
	
	
?>
<html>
<head>
<link href="css/default.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
	<code>
	<div style="margin: auto; width: 1000px">
		<div class="header">
			<img src="../img/logotipo.png" />
		</div>	
		<div class="body">
			
			<?php echo $tmp; ?>
		</div>
		<div class="footer" >
			
		</div>
	</div>
	</code>
	</body>
</html>
