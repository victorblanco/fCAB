var img = '<div id="loading" style="text-align: center; padding: 2px;"><img src="img/loading.gif" border="0" /></div>';
function muestraAyuda(){
	$('.ayudaUser').each(function(){
		
		$(this).toggle();
	});
	return false;
}

function openAyuda(clase){
	vent = window.open('app/Help?class=' + clase, 'ayuda','location=1,status=1,scrollbars=1, width=650,height=450');
	vent.focus();
}

function editActivity(id_activity, type,id_category){
	$.post("app/AdminResource.rpcForm", {"id_resource_group": type, "id_activity" : id_activity, "id_category": id_category}, 
	  	      function(data){
	    			$("#modify_activity").html( data );
		    		$("#modify_activity").dialog("open");
		    		$.cleditor.defaultOptions.controls = "bold italic underline subscript superscript font size color highlight removeformat | alignleft center alignright justify undo redo link cut copy paste pastetext ";
		    		$(".textarea_cleditor").
		    	    cleditor({
		    				width : '100%'
		    		}).focus();
	   		});

}
function editEvento(id_event, type){
	$.post("app/AdminResource.rpcForm", {"id_resource_group": 5, "id_event" : id_event}, 
	  	      function(data){
	    			$("#modify_event").html( data );
		    		$("#modify_event").dialog("open");
	   		});
}

function updatePendientes(id_category){
	cargando("#count_pendientes_validacion");
	$("#eventos_pendientes").html("&nbsp;");
	$.ajax({
		type: 'POST',
		url: 'app/AdminResource.rpcUpdatePendientes',
		data:  {"id_category": id_category },
		success: function(data){
			
			$("#count_pendientes_validacion").html(data);
			
		}
	});
}

function rellenaCategoriasRPC( comunidad ){
	cargando("#id_category_combo");
	$.ajax({
		type: 'POST',
		url: 'app/RPC.getComboCategoria',
		
		data:  {"id_community": comunidad },
		success: function(data){
			$("#id_category_combo").html(data);
		},
		complete: function(data){
			
		}
	});
	
	
}

function eliminarEvento( id, id_categoria ){
	$.post("app/RPC.deleteEvento", {"id_event": id},
	  	      function(data){
				if(data == "1"){
					updateContentajax_footer("0");
					updatePendientes(id_categoria);
				}else{
					alert("Ha ocurrido un error.")
				}
	
     });

}

function validarEvento( id, id_categoria ){
	$.post("app/RPC.validaEvento", {"id_event": id},
	  	      function(data){
				if(data == "1"){
					updateContentajax_footer("0");
					updatePendientes(id_categoria);
				}else{
					alert("Ha ocurrido un error.")
				}
	
     });

}

function eliminarEventoCalendar( id, id_categoria ){
	$.post("app/RPC.deleteEvento", {"id_event": id},
	  	      function(data){
				if(data == "1"){
					$("#aulas_eventos").dialog("close");
					location.reload(true);
				}else{
					alert("Ha ocurrido un error.")
				}
	
     });

}

function validarEventoCalendar( id, id_categoria ){
	$.post("app/RPC.validaEvento", {"id_event": id},
	  	      function(data){
				if(data == "1"){
					$("#aulas_eventos").dialog("close");
					location.reload(true);
				}else{
					alert("Ha ocurrido un error.")
				}
	
     });

}

function eliminarPost( id, id_categoria ){
	$.post("app/RPC.deletePost", {"id_post": id,"id_category" : id_categoria},
	  	      function(data){
				if(data == "1"){
					$("#aulas_eventos").dialog("close");
					location.reload(true);
				}else{
					alert("Ha ocurrido un error.")
				}
	
     });

}

function validarPost( id, id_categoria ){
	$.post("app/RPC.validaPost", {"id_post": id,"id_category" : id_categoria},
	  	      function(data){
				if(data == "1"){
					updateContentajax_footer("0");
					updatePendientes(id_categoria);
				}else{
					alert("Ha ocurrido un error.")
				}
	
     });

}

function eliminarPostHeader( id, id_categoria ){
	$.post("app/RPC.deletePostHeader", {"id_post_header": id,"id_category" : id_categoria},
	  	      function(data){
				if(data == "1"){
					updateContentajax_paginator("0");
					updatePendientes(id_categoria);
				}else{
					alert("Ha ocurrido un error.")
				}
	
     });

}

function validarPostHeader( id, id_categoria ){
	$.post("app/RPC.validaPostHeader", {"id_post_header": id,"id_category" : id_categoria},
	  	      function(data){
				if(data == "1"){
					updateContentajax_paginator("0");
					updatePendientes(id_categoria);
				}else{
					alert("Ha ocurrido un error.")
				}
	
     });

}


function validaResource( resource , community){
	cargando("#aut_" + resource);
	$.ajax({
		type: 'POST',
		url: 'app/AdminResource.rpcValidaResource',
		data:  {"id_resource": resource },
		success: function(data){
			$("#aut_" + resource ).hide();
			if (data == 1){
				$("#action_" + resource ).attr("class", "resource_admin_on_action");
				$("#vb_" + resource + "_1").hide();
				$("#vb_" + resource + "_0").show();
			}else{
				$("#action_" + resource ).attr("class", "resource_admin_action");
				$("#vb_" + resource + "_1").hide();
				$("#vb_" + resource + "_0").show();
			}
			try{
				updateContentajax_footer("0");
			}catch( e){
			}
		},
		complete: function(data){
			updatePendientes(community);
		}
	});
}
function visibleResource( resource, value, community,token ){
	$.ajax({
		type: 'POST',
		url: 'app/AdminResource.rpcVisibleResource',
		data:  {"id_resource": resource, "visible":value, "connecto_token":token },
		success: function(data){
			if(data!='ko'){
				if (value == "1"){
					$("#vb_" + resource + "_1").hide();
					$("#vb_" + resource + "_0").show();
				}else{
					$("#vb_" + resource + "_0").hide();
					$("#vb_" + resource + "_1").show();
					
				}
				if (data == "1"){
					$("#action_" + resource ).attr("class", "resource_admin_on_action");
				}else{
					$("#action_" + resource ).attr("class", "resource_admin_action");
				}
				try{
					updateContentajax_footer("0");
				}catch(e){ 
				
				}
			}else{
				alert('No ha sido posible procesar la petición');
			}
		},
		complete: function(data){
			updatePendientes(community);
		}
	});
}
function setSrc(id,src){
	document.getElementById(id).src="img/"+src;
}

function toolTips() {
		$('div.tTip').tinyTips('title');
  };

function MM_preloadImages() { //v3.0
	var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
		var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
				if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_swapImgRestore() { //v3.0
	var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
	var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
		d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
		if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
		for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
		if(!x && d.getElementById) x=d.getElementById(n); return x;
}
function MM_swapImage() { //v3.0
	var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
			if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
function confirmAction (mensaje, acion){
	if (confirm(mensaje)){
		window.location=acion;	
	}
}

function verifica(obj, impor){
	valor = parseInt(obj.value);
	if (valor > impor || isNaN(valor) ){
		alert("La cantidad no puede ser mayo de " + impor);
		obj.value = impor;
		
	}
	
}

function _checked(id){
	c = document.getElementById(id).checked;
	if (c == 0){
		document.getElementById(id).checked = 1;
	}else{
		document.getElementById(id).checked = 0;
	}
}

function confirmPagos(){
	if (confirm("Esta seguro que desea guardar los cambios")){
		document.data.submit();
		
	}
	
}

function sleep(msecs){
	var now = new Date();
	var startingMSeconds = now.getTime();
	var sleeping = true;
	var alarm;
	
	while(sleeping){
		alarm = new Date();
		alarmMSeconds = alarm.getTime();
		if(alarmMSeconds - startingMSeconds > msecs){ sleeping = false; }
	}	
}

function fadeCapa(id){
	if(document.getElementById(id).style.display != "none"){
		$('#'+id).hide();
	}else{
		$('#'+id).show();
	}
}

var lastIdUserActivity;

function addActivityComment(id,id_user,token){
	lastIdUserActivity = id;
	comment = limpiaDeEspacios(document.getElementById("text_comment_"+id).value);
	if(comment != ""){
		cargando("#activity_footer_"+id);
		$.ajax({
			type: 'POST',
			url: 'app/RPC.addComment',
			data:   {"id_user_activity": id, "id_user": id_user,"comment": comment,"connecto_token":token },
			success: function(data){
				newdata = eval('('+data+')');
				$("#lista_comments_"+id).html(newdata[0]);
				$("#activity_footer_"+id).html(newdata[1]);
				$("#text_comment_"+id).removeClass("required_");
			},
			complete: function(data){
				try{
					$('abbr.timeago').timeago();
				}catch(e){}
				$("#text_comment_"+id).attr("value","");//value = "";
			}
		});
	}else{
		
		$("#text_comment_"+id).addClass("required_");
	}
	return false;
}

function getActivityComments(id){
	if(document.getElementById("comments_"+id).style.display == "none"){
		lastIdUserActivity = id;
		cargando("#activity_footer_"+id);
		setTimeout("rpcGetActivityComments('"+id+"');fadeCapa('comments_"+id+"');",500);
	}else{
		fadeCapa('comments_'+id);
	}
	
	return false;
}

function getInitialActivityComments(id){
	if(document.getElementById("comments_"+id).style.display == "none"){
		lastIdUserActivity = id;
		cargando("#activity_footer_"+id);
		setTimeout("rpcGetInitialActivityComments('"+id+"');fadeCapa('comments_"+id+"');",500);
	}else{
		fadeCapa('comments_'+id);
	}
	
	return false;
}

function rpcGetActivityComments(id){
	$.ajax({
		type: 'POST',
		url: 'app/RPC.getActivityComments',
		data:  {"id_user_activity": id },
		success: function(data){
				newdata = eval('('+data+')');
				$("#lista_comments_"+id).html(newdata[0]);
				$("#activity_footer_"+id).html(newdata[1]);
		},
		complete: function(data){
			$("#activity_footer_"+id).removeClass("background-loading");
			try{
				$('abbr.timeago').timeago();
			}catch(e){} 
			$("#text_comment_"+id).attr("value","");//value = "";
		}
	});
}

function rpcGetInitialActivityComments(id){
	$.ajax({
		type: 'POST',
		url: 'app/RPC.getInitialActivityComments',
		data:  {"id_user_activity": id },
		success: function(data){
				newdata = eval('('+data+')');
				$("#lista_comments_"+id).html(newdata[0]);
				$("#activity_footer_"+id).html(newdata[1]);
		},
		complete: function(data){
			$("#activity_footer_"+id).removeClass("background-loading");
			try{
				$('abbr.timeago').timeago();
			}catch(e){} 
			$("#text_comment_"+id).attr("value","");//value = "";
		}
	});
}

function addResourceComment(id,id_user,token){
	comment = limpiaDeEspacios(document.getElementById("text_comment_"+id).value);
	if(comment != ""){
		cargando("#summary_"+id);
		$.ajax({
			type: 'POST',
			url: 'app/RPC.addComment',
			data:   {"id_resource": id, "id_user": id_user,"comment": comment,"connecto_token": token },
			success: function(data){
				newdata = eval('('+data+')');
				$("#lista_comments_"+id).html(newdata[0]);
				$("#summary_"+id).html(newdata[1]);
			},
			complete: function(data){
				$("#text_comment_"+id).removeClass("required_");
				try{
					$('abbr.timeago').timeago();
				}catch(e){}
				$("#text_comment_"+id).attr("value","");//value = "";
			}
		});
	}else{
		
		$("#text_comment_"+id).addClass("required_");
	}
	return false;
}

function getResourceComments(id){
	if(document.getElementById("comments_"+id).style.display == "none"){
		cargando("#summary_"+id);
		setTimeout("rpcGetResourceComments('"+id+"');fadeCapa('comments_"+id+"');",500);
	}else{
		fadeCapa('comments_'+id);
	}
	
	return false;
}

function rpcGetResourceComments(id){
	$.ajax({
		type: 'POST',
		url: 'app/Resource.rpcGetResourceComments',
		data:  {"id_resource": id },
		success: function(data){
				newdata = eval('('+data+')');
				$("#lista_comments_"+id).html(newdata[0]);
				$("#summary_"+id).html(newdata[1]);
		},
		complete: function(data){
			try{
				$('abbr.timeago').timeago();
			}catch(e){} 
			$("#text_comment_"+id).attr("value","");//value = "";
		}
	});
}

function addPostComment(id,id_user,id_post_header_type,token){
	comment = limpiaDeEspacios(document.getElementById("comentario_post").value);
	if(comment != ""){
		cargando("#layer_comment");
		//$("#layer_comment").addClass("background-loading");
		$.ajax({
			type: 'POST',
			url: 'app/RPC.addComment',
			data: {"id_post": id, "id_user": id_user,"comment": comment, "id_post_header_type": id_post_header_type, "connecto_token": token}, 
			success: function(data){
				newdata = eval ('('+data+')');
				$("#layer_comment").html(newdata[0]);
				$("#post_total_comments").html(newdata[1]);
			},
			complete: function(data){
				try{
					$('abbr.timeago').timeago();
				}catch(e){}
				$("#comentario_post").attr("value","");//value = "";
				$("#comentario_post").removeClass("required_");
			}
		});
	}else{
		
		$("#comentario_post").addClass("required_");
	}
	return false;
}

function limpiaDeEspacios(cadena){
	var return_var = "";
	return_var = cadena.replace(/^(\s|\&nbsp;)*|(\s|\&nbsp;)*$/g,"");
	return return_var;
}

function cargando( capa ){
	h = $(capa).attr("height");
	w = $(capa).attr("width");
	$(capa).attr("min-height", h);
	$(capa).attr("min-width", w);
	try{
		$(capa).html(img);
	}catch(e){}
	
}

function addContact(id_usuario,tipo,token){
	cargando("#actions_"+id_usuario);
	cargando("#profile_box_actions_"+id_usuario);
	setTimeout("addContactTO('"+id_usuario+"','"+tipo+"','"+token+"')",250);
}

function addContactTO(id_usuario,tipo,token){
	$.ajax({
		type: 'POST',
		url: 'app/Contacts.rpcAddContact',
		data:  {"id_user": id_usuario, "type": tipo, "connecto_token": token },
		success: function(data){
			if(data!='ko'){
				$("#actions_"+id_usuario).html(data);
				$("#profile_box_actions_"+id_usuario).html(data);
			}else{
				
				alert("Imposible realizar la petición");
			}
		}
	});
}

function removeContact(id_usuario,tipo,token){
	cargando("#actions_"+id_usuario);
	cargando("#profile_box_actions_"+id_usuario);
	setTimeout("removeContactTO('"+id_usuario+"','"+tipo+"','"+token+"')",250);
}

function removeContactTO(id_usuario,tipo,token){
	$.ajax({
		type: 'POST',
		url: 'app/Contacts.rpcRemoveContact',
		data:  {"id_user": id_usuario , "type": tipo, "connecto_token": token},
		success: function(data){
			if(data!='ko'){
				$("#actions_"+id_usuario).html(data);
				$("#profile_box_actions_"+id_usuario).html(data);
			}else{
				alert("Imposible realizar la petición");
			}
		}
	});
}

function addContact2(id_usuario,tipo,token){
	cargando("#actions2_"+id_usuario);
	//cargando("#profile_box_actions_"+id_usuario);
	setTimeout("addContact2TO('"+id_usuario+"','"+tipo+"','"+token+"')",250);
}

function addContact2TO(id_usuario,tipo,token){
	$.ajax({
		type: 'POST',
		url: 'app/Contacts.rpcAddContact',
		data:  {"id_user": id_usuario, "type": tipo, "connecto_token": token },
		success: function(data){
			if(data!='ko'){
				$("#actions2_"+id_usuario).html(data);
				$("#profile_box_actions_"+id_usuario).html(data);
			}else{
				
				alert("Imposible realizar la petición");
			}
		}
	});
}

function removeContact2(id_usuario,tipo,token){
	cargando("#actions2_"+id_usuario);
	//cargando("#profile_box_actions_"+id_usuario);
	setTimeout("removeContact2TO('"+id_usuario+"','"+tipo+"','"+token+"')",250);
}

function removeContact2TO(id_usuario,tipo,token){
	$.ajax({
		type: 'POST',
		url: 'app/Contacts.rpcRemoveContact',
		data:  {"id_user": id_usuario , "type": tipo, "connecto_token": token},
		success: function(data){
			if(data!='ko'){
				$("#actions2_"+id_usuario).html(data);
				$("#profile_box_actions_"+id_usuario).html(data);
			}else{
				alert("Imposible realizar la petición");
			}
		}
	});
}

function eliminarACT(id_user_activity,token){
	cargando("#activity_actions_"+id_user_activity);
	$.ajax({
		type: 'POST',
		url: 'app/RPC.rpcRemoveActivity',
		data:  {"id_user_activity": id_user_activity,"connecto_token":token },
		success: function(data){
			if(data=='ok')
				updateContentajax_footer("0");
			else alert('No se ha podido llevar a cabo la petición');
		}
	});
}

function chinchetaACT(id_user_activity,valor_chincheta,token){
	cargando("#activity_actions_"+id_user_activity);
	$.ajax({
		type: 'POST',
		url: 'app/RPC.rpcChinchetaActivity',
		data:  {"id_user_activity": id_user_activity,
				"chincheta": valor_chincheta,
				"connecto_token":token},
		success: function(data){
				if(data=='ok')
					updateContentajax_footer("0");
				else alert('No se ha podido llevar a cabo la petición');
		}
	});

}

function validaACT(id_user_activity,token){
	cargando("#activity_actions_"+id_user_activity);
	$.ajax({
		type: 'POST',
		url: 'app/RPC.rpcValidaActivity',
		data:  {"id_user_activity": id_user_activity,"connecto_token":token },
		success: function(data){
			if(data=='ok')
				updateContentajax_footer("0");
			else alert('No se ha podido llevar a cabo la petición');
		}
	});
}

function validarForm( id ){
	var error = 0;
	$("#" + id  + " .required").each(function(){
		var str = $(this).val();
		str = str.replace(/^\s*|\s*$/g,"");
		if (str == ""){
			$(this).addClass("required_");
			if($(this).is("select")){
				$(this).css("background-color","#ffcece");
			}
			if (error == 0){
				$(this).focus();
			}
			error = 1;
		}else if (str == "<br>"){
			if ($(this).css("display") == "none"){
				error = 1;
				alert(trad_campoRequerido+" "+$(this).attr("title"));
			}
		}else{
			$(this).removeClass("required_");
			if($(this).is("select")){
				$(this).css("background-color","White");
			}
		}
	});
	if (error == 0){
		return true;
	}else{
		return false;
	}

}
